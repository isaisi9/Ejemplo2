<?php
// Heading
$_['heading_title'] = 'The page you requested cannot be found!';

// Text
$_['text_error']    = 'The page you requested cannot be found.';