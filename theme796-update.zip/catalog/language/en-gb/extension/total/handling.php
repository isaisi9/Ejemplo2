<?php
// Text
$_['text_handling'] = 'Handling Fee';