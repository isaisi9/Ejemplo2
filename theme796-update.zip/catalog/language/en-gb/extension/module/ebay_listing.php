<?php
// Heading
$_['heading_title'] = 'On our eBay store';