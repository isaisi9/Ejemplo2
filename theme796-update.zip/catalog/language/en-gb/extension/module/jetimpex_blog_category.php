<?php
// Heading 
$_['heading_title']       = 'Blog Category';

// Text
$_['text_search_article'] = 'Search Article';

// Buttons
$_['button_search']       = 'Search';

?>