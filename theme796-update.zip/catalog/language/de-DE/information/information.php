<?php
/**
 * @version		$Id: information.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_error']	= 'Leider konnte die gesuchte Seite nicht gefunden werden - eventuell ein Tippfehler oder veralteter Link?';