<?php
/**
 * @version		$Id: klarna_fee.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Translation Frontend
 * @author		mic - https://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['text_klarna_fee'] = 'Gebühr Klarna';