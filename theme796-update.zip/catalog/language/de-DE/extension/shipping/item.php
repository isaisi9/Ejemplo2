<?php
/**
 * @version		$Id: item.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Translation Frontend
 * @author		mic - https://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title']		= 'Versandkosten pro Stück';
$_['text_description']	= 'Versandkosten pro Stück';