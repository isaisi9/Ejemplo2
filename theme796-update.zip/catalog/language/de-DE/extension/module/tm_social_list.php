<?php
// Text
$_['heading_title']     = 'Jetimpex Social List';