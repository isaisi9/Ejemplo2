<?php
/**
 * @version		$Id: alipay_cross.php 5035 2017-07-26 08:36:16Z mic $
 * @package		Translation Deutsch Frontend
 * @author		mic - https://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title'] = 'Alipay Cross';