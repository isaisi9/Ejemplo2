<?php
/**
 * @version		$Id: pp_standard.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Translation Frontend
 * @author		mic - https://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']	= 'Zahlungsart befindet sich momentan im <b>Testmodus</b> - es werden keine realen Zahlungen durchgeführt.';
$_['text_total']	= 'Versand, Steuern &amp; weitere Gebühren';