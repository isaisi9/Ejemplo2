<?php
/**
 * @version		$Id: basic.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Language Translation German Frontend
 * @author		mic - https://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_captcha']	= 'Captcha';

// Entry
$_['entry_captcha']	= 'Code in Box unten eingeben';

// Error
$_['error_captcha']	= 'Code stimmt nicht mit Angezeigtem überein';