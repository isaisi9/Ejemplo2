<?php
/**
 * @version		$Id: currency.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Language Translation german
 * @author		mic - http://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Text
$_['text_success']		= 'Währung erfolgreich geändert';

// Error
$_['error_permission']	= 'Keine Rechte zur Verwendung der API';
$_['error_currency']	= 'Achtung: Währungscode ist nicht gültig';