<?php
// Text
$_['text_items']     = '%s <b>%s</b>';
$_['text_empty']     = 'Ваша корзина пуста!';
$_['text_cart']      = 'Корзина';
$_['text_checkout']  = 'Заказ';
$_['text_recurring'] = 'Платежный профиль';

